<ul>
    <li><?php echo anchor('crud/create','Create') ?></li>
    <li><?php echo anchor('crud/retrieve','Retrieve') ?></li>
    <li><?php echo anchor('crud/update','Update') ?></li>
    <li><?php echo anchor('crud/delete','Delete') ?></li>
</ul>